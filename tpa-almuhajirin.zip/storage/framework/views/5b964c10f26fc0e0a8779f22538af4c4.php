<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => ['title' => 'Dashboard - TPA Al Muhajirin']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard - TPA Al Muhajirin']); ?>
     <?php $__env->slot('head', null, []); ?> 
        <!-- Custom head content -->
        <meta name="description" content="Dashboard TPA Al Muhajirin">
     <?php $__env->endSlot(); ?>

    <!-- Page Content -->
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
        <p class="text-gray-600 dark:text-gray-400">Selamat datang di TPA Al Muhajirin</p>
    </div>

    <div class="grid gap-6 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
        <?php
            $totalSantri = \App\Models\Santri::count();
            $totalUstadz = \App\Models\Ustadz::count();
            $totalClass = \App\Models\TpaClass::count();
        ?>
        <div
            class="p-6 bg-white dark:bg-neutral-900 rounded-2xl shadow-sm border border-gray-200 dark:border-neutral-700">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-2">Total Santri</h3>
            <p class="text-3xl font-bold text-blue-600 dark:text-blue-400"><?php echo e($totalSantri); ?></p>
        </div>

        <div
            class="p-6 bg-white dark:bg-neutral-900 rounded-2xl shadow-sm border border-gray-200 dark:border-neutral-700">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-2">Ustadz</h3>
            <p class="text-3xl font-bold text-green-600 dark:text-green-400"><?php echo e($totalUstadz); ?></p>
        </div>

        <div
            class="p-6 bg-white dark:bg-neutral-900 rounded-2xl shadow-sm border border-gray-200 dark:border-neutral-700">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-2">Kelas Aktif</h3>
            <p class="text-3xl font-bold text-purple-600 dark:text-purple-400"><?php echo e($totalClass); ?></p>
        </div>
    </div>

    <div class="grid gap-6 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2 2xl:grid-cols-2">
        
        <div
            class="mt-8 bg-white dark:bg-neutral-900 rounded-2xl shadow-sm border border-gray-200 dark:border-neutral-700 p-6">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Pertumbuhan Santri (Per Minggu)</h3>
            <div id="santri-growth-weekly" class="w-full h-72"></div>
        </div>
    
        
        <div
            class="mt-8 bg-white dark:bg-neutral-900 rounded-2xl shadow-sm border border-gray-200 dark:border-neutral-700 p-6">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Pertumbuhan Santri (Per Bulan)</h3>
            <div id="santri-growth-monthly" class="w-full h-72"></div>
        </div>
    
        
        <div
            class="mt-8 bg-white dark:bg-neutral-900 rounded-2xl shadow-sm border border-gray-200 dark:border-neutral-700 p-6">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Pertumbuhan Santri (Per Tahun)</h3>
            <div id="santri-growth-yearly" class="w-full h-72"></div>
        </div>
    </div>



     <?php $__env->slot('scripts', null, []); ?> 
        <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                const weekly = <?php echo json_encode($growthWeekly, 15, 512) ?>;
                const monthly = <?php echo json_encode($growthMonthly, 15, 512) ?>;
                const yearly = <?php echo json_encode($growthYearly, 15, 512) ?>;

                function renderChart(el, data, title, color) {
                    const options = {
                        chart: {
                            type: 'line',
                            height: 300,
                            toolbar: {
                                show: false
                            }
                        },
                        series: [{
                            name: title,
                            data: data.map(i => i.total)
                        }],
                        xaxis: {
                            categories: data.map(i => i.period)
                        },
                        colors: [color],
                        stroke: {
                            curve: 'smooth',
                            width: 3
                        },
                        markers: {
                            size: 4
                        },
                        grid: {
                            borderColor: '#E5E7EB'
                        }
                    };
                    new ApexCharts(document.querySelector(el), options).render();
                }

                renderChart("#santri-growth-weekly", weekly, "Mingguan", "#F59E0B"); // amber-500
                renderChart("#santri-growth-monthly", monthly, "Bulanan", "#3B82F6"); // blue-500
                renderChart("#santri-growth-yearly", yearly, "Tahunan", "#10B981"); // green-500
            });
        </script>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH D:\CODING\Laravel\tpa-almuhajirin\resources\views/dashboard.blade.php ENDPATH**/ ?>