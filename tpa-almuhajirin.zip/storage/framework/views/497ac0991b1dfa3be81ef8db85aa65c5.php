<ul class="space-y-2">
    <?php if (isset($component)) { $__componentOriginal5bfd3bb159ce0000260348a653d76773 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bfd3bb159ce0000260348a653d76773 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-item','data' => ['icon' => 'home','label' => 'Dashboard','route' => 'dashboard','active' => request()->routeIs('dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'home','label' => 'Dashboard','route' => 'dashboard','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('dashboard'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bfd3bb159ce0000260348a653d76773)): ?>
<?php $attributes = $__attributesOriginal5bfd3bb159ce0000260348a653d76773; ?>
<?php unset($__attributesOriginal5bfd3bb159ce0000260348a653d76773); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bfd3bb159ce0000260348a653d76773)): ?>
<?php $component = $__componentOriginal5bfd3bb159ce0000260348a653d76773; ?>
<?php unset($__componentOriginal5bfd3bb159ce0000260348a653d76773); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal5bfd3bb159ce0000260348a653d76773 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bfd3bb159ce0000260348a653d76773 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-item','data' => ['icon' => 'users','label' => 'Data Santri','route' => 'santri.index','active' => request()->routeIs('santri.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'users','label' => 'Data Santri','route' => 'santri.index','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('santri.*'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bfd3bb159ce0000260348a653d76773)): ?>
<?php $attributes = $__attributesOriginal5bfd3bb159ce0000260348a653d76773; ?>
<?php unset($__attributesOriginal5bfd3bb159ce0000260348a653d76773); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bfd3bb159ce0000260348a653d76773)): ?>
<?php $component = $__componentOriginal5bfd3bb159ce0000260348a653d76773; ?>
<?php unset($__componentOriginal5bfd3bb159ce0000260348a653d76773); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal5bfd3bb159ce0000260348a653d76773 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bfd3bb159ce0000260348a653d76773 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-item','data' => ['icon' => 'users','label' => 'Data Ustadz','route' => 'ustadz.index','active' => request()->routeIs('ustadz.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'users','label' => 'Data Ustadz','route' => 'ustadz.index','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('ustadz.*'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bfd3bb159ce0000260348a653d76773)): ?>
<?php $attributes = $__attributesOriginal5bfd3bb159ce0000260348a653d76773; ?>
<?php unset($__attributesOriginal5bfd3bb159ce0000260348a653d76773); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bfd3bb159ce0000260348a653d76773)): ?>
<?php $component = $__componentOriginal5bfd3bb159ce0000260348a653d76773; ?>
<?php unset($__componentOriginal5bfd3bb159ce0000260348a653d76773); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal5bfd3bb159ce0000260348a653d76773 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bfd3bb159ce0000260348a653d76773 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-item','data' => ['icon' => 'calendar','label' => 'Penjadwalan','route' => 'schedule.index','active' => request()->routeIs('schedule.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'calendar','label' => 'Penjadwalan','route' => 'schedule.index','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('schedule.*'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bfd3bb159ce0000260348a653d76773)): ?>
<?php $attributes = $__attributesOriginal5bfd3bb159ce0000260348a653d76773; ?>
<?php unset($__attributesOriginal5bfd3bb159ce0000260348a653d76773); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bfd3bb159ce0000260348a653d76773)): ?>
<?php $component = $__componentOriginal5bfd3bb159ce0000260348a653d76773; ?>
<?php unset($__componentOriginal5bfd3bb159ce0000260348a653d76773); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal5bfd3bb159ce0000260348a653d76773 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bfd3bb159ce0000260348a653d76773 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-item','data' => ['icon' => 'document','label' => 'Laporan Santri','route' => 'report.index','active' => request()->routeIs('report.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'document','label' => 'Laporan Santri','route' => 'report.index','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('report.*'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bfd3bb159ce0000260348a653d76773)): ?>
<?php $attributes = $__attributesOriginal5bfd3bb159ce0000260348a653d76773; ?>
<?php unset($__attributesOriginal5bfd3bb159ce0000260348a653d76773); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bfd3bb159ce0000260348a653d76773)): ?>
<?php $component = $__componentOriginal5bfd3bb159ce0000260348a653d76773; ?>
<?php unset($__componentOriginal5bfd3bb159ce0000260348a653d76773); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal5bfd3bb159ce0000260348a653d76773 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bfd3bb159ce0000260348a653d76773 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-item','data' => ['icon' => 'folder','label' => 'Kelola Dokumen','route' => 'document.index','active' => request()->routeIs('document.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'folder','label' => 'Kelola Dokumen','route' => 'document.index','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('document.*'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bfd3bb159ce0000260348a653d76773)): ?>
<?php $attributes = $__attributesOriginal5bfd3bb159ce0000260348a653d76773; ?>
<?php unset($__attributesOriginal5bfd3bb159ce0000260348a653d76773); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bfd3bb159ce0000260348a653d76773)): ?>
<?php $component = $__componentOriginal5bfd3bb159ce0000260348a653d76773; ?>
<?php unset($__componentOriginal5bfd3bb159ce0000260348a653d76773); ?>
<?php endif; ?>

</ul>
<?php /**PATH D:\CODING\Laravel\tpa-almuhajirin\resources\views/components/sidebar-navigation.blade.php ENDPATH**/ ?>