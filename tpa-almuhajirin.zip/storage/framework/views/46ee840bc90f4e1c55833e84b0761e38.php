<!-- Desktop Sidebar -->
<aside class="hidden lg:flex lg:flex-col lg:w-64 lg:bg-white lg:border-r lg:border-gray-200 dark:lg:bg-neutral-800 dark:lg:border-neutral-700">
    <div class="flex flex-col h-full">
        <!-- Sidebar Header -->
        <div class="p-4 border-b border-gray-200 dark:border-neutral-700">
            <h2 class="font-semibold text-lg text-gray-900 dark:text-white">
                Sidebar Navigation
            </h2>
        </div>

        <!-- Navigation -->
        <nav class="flex-1 overflow-y-auto p-4">
            <?php if (isset($component)) { $__componentOriginal693605bd7783d79e9c5f8a65b18753b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal693605bd7783d79e9c5f8a65b18753b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-navigation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal693605bd7783d79e9c5f8a65b18753b8)): ?>
<?php $attributes = $__attributesOriginal693605bd7783d79e9c5f8a65b18753b8; ?>
<?php unset($__attributesOriginal693605bd7783d79e9c5f8a65b18753b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal693605bd7783d79e9c5f8a65b18753b8)): ?>
<?php $component = $__componentOriginal693605bd7783d79e9c5f8a65b18753b8; ?>
<?php unset($__componentOriginal693605bd7783d79e9c5f8a65b18753b8); ?>
<?php endif; ?>
        </nav>

        <!-- User Profile -->
        
    </div>
</aside>

<!-- Mobile Sidebar -->
<div id="mobile-sidebar" class="hs-overlay fixed inset-0 z-60 lg:hidden hs-overlay-open:translate-x-0 -translate-x-full transition-transform duration-300">
    <div class="flex h-full max-w-xs w-full">
        <div class="flex flex-col w-full bg-white border-r border-gray-200 dark:bg-neutral-800 dark:border-neutral-700">
            <!-- Mobile Header -->
            <div class="p-4 border-b border-gray-200 dark:border-neutral-700 flex justify-between items-center">
                <h2 class="font-semibold text-lg text-gray-900 dark:text-white">
                    Sidebar Navigation
                </h2>
                <button type="button" 
                        class="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-neutral-700" 
                        data-hs-overlay="#mobile-sidebar">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>

            <!-- Mobile Navigation -->
            <nav class="flex-1 overflow-y-auto p-4">
                <?php if (isset($component)) { $__componentOriginal693605bd7783d79e9c5f8a65b18753b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal693605bd7783d79e9c5f8a65b18753b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-navigation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal693605bd7783d79e9c5f8a65b18753b8)): ?>
<?php $attributes = $__attributesOriginal693605bd7783d79e9c5f8a65b18753b8; ?>
<?php unset($__attributesOriginal693605bd7783d79e9c5f8a65b18753b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal693605bd7783d79e9c5f8a65b18753b8)): ?>
<?php $component = $__componentOriginal693605bd7783d79e9c5f8a65b18753b8; ?>
<?php unset($__componentOriginal693605bd7783d79e9c5f8a65b18753b8); ?>
<?php endif; ?>
            </nav>

            <!-- Mobile User Profile -->
            
        </div>
    </div>
</div><?php /**PATH D:\CODING\Laravel\tpa-almuhajirin\resources\views/components/sidebar.blade.php ENDPATH**/ ?>