<div id="edit-santri-modal-<?php echo e($santri->id); ?>" class="hs-overlay hidden size-full fixed top-0 start-0 z-80 overflow-x-hidden overflow-y-auto">
    <div class="hs-overlay-open:mt-7 hs-overlay-open:opacity-100 hs-overlay-open:duration-500 mt-0 opacity-0 ease-out transition-all sm:max-w-4xl sm:w-full m-3 sm:mx-auto">
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm dark:bg-neutral-900 dark:border-neutral-700">
            <div class="p-4 overflow-y-auto">
                <div class="flex justify-between items-center py-3 px-4 border-b dark:border-neutral-700">
                    <h3 class="font-bold text-gray-800 dark:text-white">Edit Data Santri</h3>
                    <button type="button" class="flex justify-center items-center size-7 text-sm font-semibold rounded-full border border-transparent text-gray-800 hover:bg-gray-100 disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-neutral-700" data-hs-overlay="#edit-santri-modal-<?php echo e($santri->id); ?>">
                        <span class="sr-only">Close</span>
                        <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="m18 6-12 12"/>
                            <path d="m6 6 12 12"/>
                        </svg>
                    </button>
                </div>

                <form method="POST" action="<?php echo e(route('santri.update', $santri)); ?>" enctype="multipart/form-data" class="p-4">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <!-- Left Column -->
                        <div class="space-y-4">
                            <!-- NIS -->
                            <div>
                                <label class="block text-sm font-medium mb-2 dark:text-white">NIS *</label>
                                <input type="text" name="nis" required value="<?php echo e($santri->nis); ?>"
                                       class="py-3 px-4 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600">
                            </div>

                            <!-- Nama Lengkap -->
                            <div>
                                <label class="block text-sm font-medium mb-2 dark:text-white">Nama Lengkap *</label>
                                <input type="text" name="full_name" required value="<?php echo e($santri->full_name); ?>"
                                       class="py-3 px-4 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600">
                            </div>

                            <!-- Nama Panggilan -->
                            <div>
                                <label class="block text-sm font-medium mb-2 dark:text-white">Nama Panggilan</label>
                                <input type="text" name="nickname" value="<?php echo e($santri->nickname); ?>"
                                       class="py-3 px-4 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600">
                            </div>

                            <!-- Jenis Kelamin -->
                            <div>
                                <label class="block text-sm font-medium mb-2 dark:text-white">Jenis Kelamin *</label>
                                <select name="gender" required class="py-3 px-4 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:focus:ring-neutral-600">
                                    <option value="L" <?php echo e($santri->gender === 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                                    <option value="P" <?php echo e($santri->gender === 'P' ? 'selected' : ''); ?>>Perempuan</option>
                                </select>
                            </div>

                            <!-- Tanggal Lahir -->
                            <div>
                                <label class="block text-sm font-medium mb-2 dark:text-white">Tanggal Lahir *</label>
                                <input type="date" name="birth_date" required value="<?php echo e($santri->birth_date->format('Y-m-d')); ?>"
                                       class="py-3 px-4 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:focus:ring-neutral-600">
                            </div>

                            <!-- Tempat Lahir -->
                            <div>
                                <label class="block text-sm font-medium mb-2 dark:text-white">Tempat Lahir *</label>
                                <input type="text" name="birth_place" required value="<?php echo e($santri->birth_place); ?>"
                                       class="py-3 px-4 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600">
                            </div>

                            <!-- Alamat -->
                            <div>
                                <label class="block text-sm font-medium mb-2 dark:text-white">Alamat *</label>
                                <textarea name="address" required rows="3"
                                          class="py-3 px-4 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600"><?php echo e($santri->address); ?></textarea>
                            </div>
                        </div>

                        <!-- Right Column -->
                        <div class="space-y-4">
                            <!-- Foto -->
                            <div>
                                <label class="block text-sm font-medium mb-2 dark:text-white">Foto</label>
                                <?php if($santri->photo_path): ?>
                                    <div class="mb-2">
                                        <img src="<?php echo e($santri->photo_url); ?>" alt="Current photo" class="w-20 h-20 object-cover rounded-lg">
                                        <p class="text-xs text-gray-500 mt-1">Foto saat ini</p>
                                    </div>
                                <?php endif; ?>
                                <input type="file" name="photo" accept="image/*"
                                       class="block w-full border border-gray-200 shadow-sm rounded-lg text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 file:bg-gray-50 file:border-0 file:me-4 file:py-3 file:px-4 dark:file:bg-neutral-700 dark:file:text-neutral-400">
                            </div>

                            <!-- Nama Ayah -->
                            <div>
                                <label class="block text-sm font-medium mb-2 dark:text-white">Nama Ayah *</label>
                                <input type="text" name="father_name" required value="<?php echo e($santri->father_name); ?>"
                                       class="py-3 px-4 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600">
                            </div>

                            <!-- Nama Ibu -->
                            <div>
                                <label class="block text-sm font-medium mb-2 dark:text-white">Nama Ibu *</label>
                                <input type="text" name="mother_name" required value="<?php echo e($santri->mother_name); ?>"
                                       class="py-3 px-4 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600">
                            </div>

                            <!-- Nama Wali -->
                            <div>
                                <label class="block text-sm font-medium mb-2 dark:text-white">Nama Wali</label>
                                <input type="text" name="guardian_name" value="<?php echo e($santri->guardian_name); ?>"
                                       class="py-3 px-4 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600">
                            </div>

                            <!-- No. HP Wali -->
                            <div>
                                <label class="block text-sm font-medium mb-2 dark:text-white">No. HP Wali *</label>
                                <input type="text" name="guardian_phone" required value="<?php echo e($santri->guardian_phone); ?>"
                                       class="py-3 px-4 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600">
                            </div>

                            <!-- Kelas -->
                            <div>
                                <label class="block text-sm font-medium mb-2 dark:text-white">Kelas *</label>
                                <select name="class_id" required class="py-3 px-4 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:focus:ring-neutral-600">
                                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($class->id); ?>" <?php echo e($santri->class_id === $class->id ? 'selected' : ''); ?>>
                                            <?php echo e($class->display_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- Tanggal Masuk -->
                            <div>
                                <label class="block text-sm font-medium mb-2 dark:text-white">Tanggal Masuk *</label>
                                <input type="date" name="enrollment_date" required value="<?php echo e($santri->enrollment_date->format('Y-m-d')); ?>"
                                       class="py-3 px-4 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:focus:ring-neutral-600">
                            </div>

                            <!-- Status -->
                            <div>
                                <label class="block text-sm font-medium mb-2 dark:text-white">Status *</label>
                                <select name="status" required class="py-3 px-4 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:focus:ring-neutral-600">
                                    <option value="active" <?php echo e($santri->status === 'active' ? 'selected' : ''); ?>>Aktif</option>
                                    <option value="inactive" <?php echo e($santri->status === 'inactive' ? 'selected' : ''); ?>>Tidak Aktif</option>
                                    <option value="graduated" <?php echo e($santri->status === 'graduated' ? 'selected' : ''); ?>>Lulus</option>
                                    <option value="dropped" <?php echo e($santri->status === 'dropped' ? 'selected' : ''); ?>>Keluar</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="flex justify-end items-center gap-x-2 py-3 px-4 border-t dark:border-neutral-700 mt-6">
                        <button type="button" class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-200 bg-white text-gray-800 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-white dark:hover:bg-neutral-800" data-hs-overlay="#edit-santri-modal-<?php echo e($santri->id); ?>">
                            Batal
                        </button>
                        <button type="submit" class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none">
                            Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\CODING\Laravel\tpa-almuhajirin\resources\views/santri/partials/edit-modal.blade.php ENDPATH**/ ?>