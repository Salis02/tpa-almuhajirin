<div id="show-schedule-modal-<?php echo e($schedule->id); ?>" class="hs-overlay hidden size-full fixed top-0 start-0 z-80 overflow-x-hidden overflow-y-auto">
    <div class="hs-overlay-open:mt-7 hs-overlay-open:opacity-100 hs-overlay-open:duration-500 mt-0 opacity-0 ease-out transition-all sm:max-w-3xl sm:w-full m-3 sm:mx-auto">
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm dark:bg-neutral-900 dark:border-neutral-700">
            <div class="flex justify-between items-center py-3 px-4 border-b dark:border-neutral-700">
                <h3 class="font-bold text-gray-800 dark:text-white">Detail Jadwal KBM</h3>
                <button type="button" class="flex justify-center items-center size-7 text-sm font-semibold rounded-full border border-transparent text-gray-800 hover:bg-gray-100 disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-neutral-700" data-hs-overlay="#show-schedule-modal-<?php echo e($schedule->id); ?>">
                    <span class="sr-only">Close</span>
                    <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="m18 6-12 12"/>
                        <path d="m6 6 12 12"/>
                    </svg>
                </button>
            </div>

            <div class="p-4 overflow-y-auto max-h-[80vh]">
                <div class="space-y-6">
                    <!-- Header Info -->
                    <div class="text-center border-b border-gray-200 dark:border-neutral-700 pb-6">
                        <h4 class="text-xl font-bold text-gray-900 dark:text-white mb-2"><?php echo e($schedule->title); ?></h4>
                        <div class="flex justify-center space-x-2">
                            <span class="inline-flex items-center gap-x-1.5 py-1.5 px-3 rounded-full text-xs font-medium 
                                <?php if($schedule->scheduleType->name === 'setoran'): ?> bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400
                                <?php elseif($schedule->scheduleType->name === 'praktek'): ?> bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400
                                <?php else: ?> bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400 <?php endif; ?>">
                                <?php echo e($schedule->scheduleType->display_name); ?>

                            </span>
                            <span class="inline-flex items-center gap-x-1.5 py-1.5 px-3 rounded-full text-xs font-medium 
                                <?php echo e($schedule->status === 'scheduled' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400' : 
                                   ($schedule->status === 'completed' ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400' : 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400')); ?>">
                                <?php echo e(ucfirst($schedule->status)); ?>

                            </span>
                        </div>
                    </div>

                    <!-- Schedule Details -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <h5 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Informasi Jadwal</h5>
                            <div class="space-y-3">
                                <div>
                                    <label class="block text-sm font-medium text-gray-500 dark:text-gray-400">Kelas</label>
                                    <p class="text-sm text-gray-900 dark:text-white"><?php echo e($schedule->tpaClass->display_name); ?></p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-500 dark:text-gray-400">Ustadz/Ustadzah</label>
                                    <p class="text-sm text-gray-900 dark:text-white"><?php echo e($schedule->ustadz->full_name); ?></p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-500 dark:text-gray-400">Tanggal</label>
                                    <p class="text-sm text-gray-900 dark:text-white"><?php echo e($schedule->date->format('l, d F Y')); ?></p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-500 dark:text-gray-400">Waktu</label>
                                  <p class="text-sm text-gray-900 dark:text-white">
    <?php echo e($schedule->start_time_carbon->format('H:i')); ?> - 
    <?php echo e($schedule->end_time_carbon->format('H:i')); ?>

    (<?php echo e($schedule->duration); ?> menit)
</p>


                                </div>
                                <?php if($schedule->location): ?>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-500 dark:text-gray-400">Lokasi</label>
                                        <p class="text-sm text-gray-900 dark:text-white"><?php echo e($schedule->location); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div>
                            <h5 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Peserta (<?php echo e($schedule->participant_count); ?>)</h5>
                            <div class="max-h-40 overflow-y-auto">
                                <?php if($schedule->participants->count() > 0): ?>
                                    <div class="space-y-2">
                                        <?php $__currentLoopData = $schedule->participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="flex items-center justify-between p-2 bg-gray-50 dark:bg-neutral-800 rounded-lg">
                                                <div>
                                                    <p class="text-sm font-medium text-gray-900 dark:text-white"><?php echo e($participant->santri->full_name); ?></p>
                                                    <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($participant->santri->nis); ?></p>
                                                </div>
                                                <span class="text-xs px-2 py-1 rounded-full 
                                                    <?php echo e($participant->status === 'present' ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400' : 
                                                       ($participant->status === 'absent' ? 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400')); ?>">
                                                    <?php echo e(ucfirst($participant->status)); ?>

                                                </span>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <p class="text-sm text-gray-500 dark:text-gray-400">Belum ada peserta terdaftar</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <?php if($schedule->description): ?>
                        <div>
                            <h5 class="text-lg font-semibold text-gray-900 dark:text-white mb-2">Deskripsi</h5>
                            <p class="text-sm text-gray-600 dark:text-gray-400"><?php echo e($schedule->description); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php if($schedule->notes): ?>
                        <div>
                            <h5 class="text-lg font-semibold text-gray-900 dark:text-white mb-2">Catatan</h5>
                            <p class="text-sm text-gray-600 dark:text-gray-400"><?php echo e($schedule->notes); ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="flex justify-end items-center gap-x-2 py-3 px-4 border-t dark:border-neutral-700 mt-6">
                    <button type="button" class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-200 bg-white text-gray-800 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-white dark:hover:bg-neutral-800" data-hs-overlay="#show-schedule-modal-<?php echo e($schedule->id); ?>">
                        Tutup
                    </button>
                    <button type="button" class="py-2 px-3 inline-flex items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-yellow-600 text-white hover:bg-yellow-700 disabled:opacity-50 disabled:pointer-events-none" data-hs-overlay="#edit-schedule-modal-<?php echo e($schedule->id); ?>">
                        Edit
                    </button>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\CODING\Laravel\tpa-almuhajirin\resources\views/schedule/partials/show-modal.blade.php ENDPATH**/ ?>