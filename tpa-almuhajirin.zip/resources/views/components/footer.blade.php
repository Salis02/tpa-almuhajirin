
<footer class="bg-white dark:bg-neutral-900 border-t border-gray-200 dark:border-neutral-700 mt-auto">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div class="text-center text-sm text-gray-500 dark:text-neutral-400">
            &copy; {{ date('Y') }} TPA Al Muhajirin. All rights reserved.
        </div>
    </div>
</footer>